%% MATLAB program: combplot_endosimul_death.m (created and run in R2017a on MacBook Pro OS)
%
%  Purpose:        This code generates and saves Figure 4 in DP combining 3 US scenario curves into 12 panels/subplots.
%
%  Excel Input:    USGSW_amECsq_lockdown_death_1SDsimul.xlsx - simulation assuming LF 1SD down in new SS = 1% of LF dead
%                  USGSW_amECsq_lockdown_death_3SDsimul.xlsx - simulation assuming LF 3SD down in new SS = 1% of LF dead
%                  USGSW_amECsq_lockdown_death_5SDsimul.xlsx - simulation assuming LF 5SD down in new SS = 1% of LF dead
%
%  First created:  5 April 2020, by Alexander Mihailov
%  Last modified:  10 May 2020, by Alexander Mihailov

%% Housekeeping and opening diary
close all                          % close all open figures
clear all                          % clear all earlier output
clc                                % clear command window
diary us_endosimul.txt             % create a diary log (*.txt) file saving the output from the command window
tic                                % start stopwatch timer
t = datetime('now')                % return a datetime scalar representing the current date and time

%% Define the vectors of simulated endogenous variables, reading into the respective Excel columns (as below)

% ADJUST FILENAME AND RANGE respectively below!!!

us_endosimul_1SD = xlsread('USGSW_amECsq_lockdown_death_1SDsimul.xlsx','Sheet1','A1:BJ44') % 1SD LS shock down permanent
us_endosimul_3SD = xlsread('USGSW_amECsq_lockdown_death_3SDsimul.xlsx','Sheet1','A1:BJ44') % 3SD LS shock down permanent
us_endosimul_5SD = xlsread('USGSW_amECsq_lockdown_death_5SDsimul.xlsx','Sheet1','A1:BJ44') % 5SD LS shock down permanent

% Wage rate (row 32 in xlsx and var 32 in Dynare; w in code)

us_endosimul_1SD_32 = us_endosimul_1SD(32,:); % 1SD LS shock down permanent
us_endosimul_3SD_32 = us_endosimul_3SD(32,:); % 3SD LS shock down permanent
us_endosimul_5SD_32 = us_endosimul_5SD(32,:); % 5SD LS shock down permanent

% Nominal policy rate (row 33 in xlsx and var 33 in Dynare; r in code)

us_endosimul_1SD_33 = us_endosimul_1SD(33,:);
us_endosimul_3SD_33 = us_endosimul_3SD(33,:);
us_endosimul_5SD_33 = us_endosimul_5SD(33,:);

% Consumption (row 27 in xlsx and var 32 in Dynare; c in code)

us_endosimul_1SD_27 = us_endosimul_1SD(27,:);
us_endosimul_3SD_27 = us_endosimul_3SD(27,:);
us_endosimul_5SD_27 = us_endosimul_5SD(27,:);

% Investment (row 28 in xlsx and var 28 in Dynare; inve in code)

us_endosimul_1SD_28 = us_endosimul_1SD(28,:);
us_endosimul_3SD_28 = us_endosimul_3SD(28,:);
us_endosimul_5SD_28 = us_endosimul_5SD(28,:);

% Output (row 29 in xlsx and var 29 in Dynare; y in code)

us_endosimul_1SD_29 = us_endosimul_1SD(29,:);
us_endosimul_3SD_29 = us_endosimul_3SD(29,:);
us_endosimul_5SD_29 = us_endosimul_5SD(29,:);

% Natural (flexible-price) output (row 18 in xlsx and var 18 in Dynare; yf in code)

us_endosimul_1SD_18 = us_endosimul_1SD(18,:);
us_endosimul_3SD_18 = us_endosimul_3SD(18,:);
us_endosimul_5SD_18 = us_endosimul_5SD(18,:);

% Output gap (row 44 in xlsx and var 44 in Dynare; ygap in code)

us_endosimul_1SD_44 = us_endosimul_1SD(44,:);
us_endosimul_3SD_44 = us_endosimul_3SD(44,:);
us_endosimul_5SD_44 = us_endosimul_5SD(44,:);

% Inflation rate (row 31 in xlsx and var 31 in Dynare; pinf in code)

us_endosimul_1SD_31 = us_endosimul_1SD(31,:);
us_endosimul_3SD_31 = us_endosimul_3SD(31,:);
us_endosimul_5SD_31 = us_endosimul_5SD(31,:);

% Unemployment rate (row 3 in xlsx and var 3 in Dynare; u in code)

us_endosimul_1SD_3 = us_endosimul_1SD(3,:);
us_endosimul_3SD_3 = us_endosimul_3SD(3,:);
us_endosimul_5SD_3 = us_endosimul_5SD(3,:);

% Employment rate (row 30 in xlsx and var 30 in Dynare; lab in code)

us_endosimul_1SD_30 = us_endosimul_1SD(30,:);
us_endosimul_3SD_30 = us_endosimul_3SD(30,:);
us_endosimul_5SD_30 = us_endosimul_5SD(30,:);

% Labour force participation rate (row 4 in xlsx and var 4 in Dynare; labstar in code) 

us_endosimul_1SD_4 = us_endosimul_1SD(4,:);
us_endosimul_3SD_4 = us_endosimul_3SD(4,:);
us_endosimul_5SD_4 = us_endosimul_5SD(4,:);

% Disutility of labor weight in U f-n = adverse LS shock in GSW (row 5 in xlsx and var 5 in Dynare; labstar in code)

us_endosimul_1SD_5 = us_endosimul_1SD(5,:);
us_endosimul_3SD_5 = us_endosimul_3SD(5,:);
us_endosimul_5SD_5 = us_endosimul_5SD(5,:);

%Figure (without caption title)
figure

% x-axis: 62 quarters - quarter 1 initial, quarter 62 terminal, in-between 60 quarters entered in Dynare simul command
tt=1:62;  % AM200320: Dynare adds to the 60 quarters entered in "simul" above both the initial and the terminal values!
          % The command "tt" defines the horizontal axis length in "plot" next, corresponding to the specified periods!

subplot(3,4,1);
plot(tt,us_endosimul_1SD_32,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_32,'LineWidth',2);
plot(tt,us_endosimul_5SD_32,'LineWidth',2);
hold off
hleg1 = legend({'1SD LS shock down','3SD LS shock down','5SD LS shock down'},'FontSize',10);
set(hleg1,'Location','NorthEast')
title('Wage Rate')
grid on

subplot(3,4,2);
plot(tt,us_endosimul_1SD_33,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_33,'LineWidth',2);
plot(tt,us_endosimul_5SD_33,'LineWidth',2);
hold off
title('Nominal Policy Rate')
grid on

subplot(3,4,3);
plot(tt,us_endosimul_1SD_27,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_27,'LineWidth',2);
plot(tt,us_endosimul_5SD_27,'LineWidth',2);
hold off
title('Consumption')
grid on

subplot(3,4,4);
plot(tt,us_endosimul_1SD_28,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_28,'LineWidth',2);
plot(tt,us_endosimul_5SD_28,'LineWidth',2);
hold off
title('Investment')
grid on

subplot(3,4,5);
plot(tt,us_endosimul_1SD_29,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_29,'LineWidth',2);
plot(tt,us_endosimul_5SD_29,'LineWidth',2);
hold off
title('Output')
grid on

subplot(3,4,6);
plot(tt,us_endosimul_1SD_18,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_18,'LineWidth',2);
plot(tt,us_endosimul_5SD_18,'LineWidth',2);
hold off
title('Natural (Flex-Price) Output')
grid on

subplot(3,4,7);
plot(tt,us_endosimul_1SD_44,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_44,'LineWidth',2);
plot(tt,us_endosimul_5SD_44,'LineWidth',2);
hold off       
title('Output Gap')
grid on

subplot(3,4,8);
plot(tt,us_endosimul_1SD_31,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_31,'LineWidth',2);
plot(tt,us_endosimul_5SD_31,'LineWidth',2);
hold off
title('Inflation Rate')
grid on

subplot(3,4,9);
plot(tt,us_endosimul_1SD_3,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_3,'LineWidth',2);
plot(tt,us_endosimul_5SD_3,'LineWidth',2);
hold off
title('Unemployment Rate');
grid on

subplot(3,4,10);
plot(tt,us_endosimul_1SD_30,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_30,'LineWidth',2);
plot(tt,us_endosimul_5SD_30,'LineWidth',2);
hold off
title('Employment Rate')
grid on

subplot(3,4,11);
plot(tt,us_endosimul_1SD_4,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_4,'LineWidth',2);
plot(tt,us_endosimul_5SD_4,'LineWidth',2);
hold off
title('Labor Force Participation Rate')
grid on

subplot(3,4,12);
plot(tt,us_endosimul_1SD_5,'LineWidth',2);
hold on
plot(tt,us_endosimul_3SD_5,'LineWidth',2);
plot(tt,us_endosimul_5SD_5,'LineWidth',2);
hold off
title('Disutility of Labor Weight in Felicity Function')
grid on

saveas(gcf,'USGSW_amECsq_lockdown_death_simul3scenarios.fig')  % editable MATLAB format
saveas(gcf,'USGSW_amECsq_lockdown_death_simul3scenarios.eps')
saveas(gcf,'USGSW_amECsq_lockdown_death_simul3scenarios.epsc')
saveas(gcf,'USGSW_amECsq_lockdown_death_simul3scenarios.jpg')
saveas(gcf,'USGSW_amECsq_lockdown_death_simul3scenarios.png')
saveas(gcf,'USGSW_amECsq_lockdown_death_simul3scenarios.bmp')