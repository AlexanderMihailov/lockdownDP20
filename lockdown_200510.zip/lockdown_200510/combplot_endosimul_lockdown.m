%% MATLAB program: combplot_endosimul_lockdown.m (created and run in R2017a on MacBook Pro OS)
%
%  Purpose:        This code generates and saves Figure 1 in DP combining 3 US scenario curves into 12 panels/subplots.
%
%  Excel Input:    USGSW_amECsq_lockdown_100SD1Qsimul.xlsx - simulation assuming LF 100SD up for 1Q
%                  USGSW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
%                  USGSW_amECsq_lockdown_100SD3Qsimul.xlsx - simulation assuming LF 100SD up for 3Q
%
%  First created:  5 April 2020, by Alexander Mihailov
%  Last modified:  10 May 2020, by Alexander Mihailov

%% Housekeeping and opening diary
close all                          % close all open figures
clear all                          % clear all earlier output
clc                                % clear command window
diary us_endosimul.txt             % create a diary log (*.txt) file saving the output from the command window
tic                                % start stopwatch timer
t = datetime('now')                % return a datetime scalar representing the current date and time

%% Define the vectors of simulated endogenous variables, reading into the respective Excel columns (as below)

% ADJUST FILENAME AND RANGE respectively below!!!

us_endosimul_100SD1Q = xlsread('USGSW_amECsq_lockdown_100SD1Qsimul.xlsx','Sheet1','A1:BJ44') % 100SD1Q LS shock down permanent
us_endosimul_100SD2Q = xlsread('USGSW_amECsq_lockdown_100SD2Qsimul.xlsx','Sheet1','A1:BJ44') % 100SD2Q LS shock down permanent
us_endosimul_100SD3Q = xlsread('USGSW_amECsq_lockdown_100SD3Qsimul.xlsx','Sheet1','A1:BJ44') % 100SD3Q LS shock down permanent

% Wage rate (row 32 in xlsx and var 32 in Dynare; w in code)

us_endosimul_100SD1Q_32 = us_endosimul_100SD1Q(32,:); % 100SD1Q LS shock down permanent
us_endosimul_100SD2Q_32 = us_endosimul_100SD2Q(32,:); % 100SD2Q LS shock down permanent
us_endosimul_100SD3Q_32 = us_endosimul_100SD3Q(32,:); % 100SD3Q LS shock down permanent

% Nominal policy rate (row 33 in xlsx and var 33 in Dynare; r in code)

us_endosimul_100SD1Q_33 = us_endosimul_100SD1Q(33,:);
us_endosimul_100SD2Q_33 = us_endosimul_100SD2Q(33,:);
us_endosimul_100SD3Q_33 = us_endosimul_100SD3Q(33,:);

% Consumption (row 27 in xlsx and var 32 in Dynare; c in code)

us_endosimul_100SD1Q_27 = us_endosimul_100SD1Q(27,:);
us_endosimul_100SD2Q_27 = us_endosimul_100SD2Q(27,:);
us_endosimul_100SD3Q_27 = us_endosimul_100SD3Q(27,:);

% Investment (row 28 in xlsx and var 28 in Dynare; inve in code)

us_endosimul_100SD1Q_28 = us_endosimul_100SD1Q(28,:);
us_endosimul_100SD2Q_28 = us_endosimul_100SD2Q(28,:);
us_endosimul_100SD3Q_28 = us_endosimul_100SD3Q(28,:);

% Output (row 29 in xlsx and var 29 in Dynare; y in code)

us_endosimul_100SD1Q_29 = us_endosimul_100SD1Q(29,:);
us_endosimul_100SD2Q_29 = us_endosimul_100SD2Q(29,:);
us_endosimul_100SD3Q_29 = us_endosimul_100SD3Q(29,:);

% Natural (flexible-price) output (row 18 in xlsx and var 18 in Dynare; yf in code)

us_endosimul_100SD1Q_18 = us_endosimul_100SD1Q(18,:);
us_endosimul_100SD2Q_18 = us_endosimul_100SD2Q(18,:);
us_endosimul_100SD3Q_18 = us_endosimul_100SD3Q(18,:);

% Output gap (row 44 in xlsx and var 44 in Dynare; ygap in code)

us_endosimul_100SD1Q_44 = us_endosimul_100SD1Q(44,:);
us_endosimul_100SD2Q_44 = us_endosimul_100SD2Q(44,:);
us_endosimul_100SD3Q_44 = us_endosimul_100SD3Q(44,:);

% Inflation rate (row 31 in xlsx and var 31 in Dynare; pinf in code)

us_endosimul_100SD1Q_31 = us_endosimul_100SD1Q(31,:);
us_endosimul_100SD2Q_31 = us_endosimul_100SD2Q(31,:);
us_endosimul_100SD3Q_31 = us_endosimul_100SD3Q(31,:);

% Unemployment rate (row 3 in xlsx and var 3 in Dynare; u in code)

us_endosimul_100SD1Q_3 = us_endosimul_100SD1Q(3,:);
us_endosimul_100SD2Q_3 = us_endosimul_100SD2Q(3,:);
us_endosimul_100SD3Q_3 = us_endosimul_100SD3Q(3,:);

% Employment rate (row 30 in xlsx and var 30 in Dynare; lab in code)

us_endosimul_100SD1Q_30 = us_endosimul_100SD1Q(30,:);
us_endosimul_100SD2Q_30 = us_endosimul_100SD2Q(30,:);
us_endosimul_100SD3Q_30 = us_endosimul_100SD3Q(30,:);

% Labour force participation rate (row 4 in xlsx and var 4 in Dynare; labstar in code) 

us_endosimul_100SD1Q_4 = us_endosimul_100SD1Q(4,:);
us_endosimul_100SD2Q_4 = us_endosimul_100SD2Q(4,:);
us_endosimul_100SD3Q_4 = us_endosimul_100SD3Q(4,:);

% Disutility of labor weight in U f-n = adverse LS shock in GSW (row 5 in xlsx and var 5 in Dynare; labstar in code)

us_endosimul_100SD1Q_5 = us_endosimul_100SD1Q(5,:);
us_endosimul_100SD2Q_5 = us_endosimul_100SD2Q(5,:);
us_endosimul_100SD3Q_5 = us_endosimul_100SD3Q(5,:);

%Figure (without caption title)
figure

% x-axis: 62 quarters - quarter 1 initial, quarter 62 terminal, in-between 60 quarters entered in Dynare simul command
tt=1:62;  % AM200320: Dynare adds to the 60 quarters entered in "simul" above both the initial and the terminal values!
          % The command "tt" defines the horizontal axis length in "plot" next, corresponding to the specified periods!

subplot(3,4,1);
plot(tt,us_endosimul_100SD1Q_32,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_32,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_32,'LineWidth',2);
hold off
hleg1 = legend({'100SD LS shock up for 1Q','100SD LS shock up for 2Q','100SD LS shock up for 3Q'},'FontSize',10);
set(hleg1,'Location','NorthEast')
title('Wage Rate')
grid on

subplot(3,4,2);
plot(tt,us_endosimul_100SD1Q_33,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_33,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_33,'LineWidth',2);
hold off
title('Nominal Policy Rate')
grid on

subplot(3,4,3);
plot(tt,us_endosimul_100SD1Q_27,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_27,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_27,'LineWidth',2);
hold off
title('Consumption')
grid on

subplot(3,4,4);
plot(tt,us_endosimul_100SD1Q_28,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_28,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_28,'LineWidth',2);
hold off
title('Investment')
grid on

subplot(3,4,5);
plot(tt,us_endosimul_100SD1Q_29,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_29,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_29,'LineWidth',2);
hold off
title('Output')
grid on

subplot(3,4,6);
plot(tt,us_endosimul_100SD1Q_18,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_18,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_18,'LineWidth',2);
hold off
title('Natural (Flex-Price) Output')
grid on

subplot(3,4,7);
plot(tt,us_endosimul_100SD1Q_44,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_44,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_44,'LineWidth',2);
hold off       
title('Output Gap')
grid on

subplot(3,4,8);
plot(tt,us_endosimul_100SD1Q_31,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_31,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_31,'LineWidth',2);
hold off
title('Inflation Rate')
grid on

subplot(3,4,9);
plot(tt,us_endosimul_100SD1Q_3,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_3,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_3,'LineWidth',2);
hold off
title('Unemployment Rate');
grid on

subplot(3,4,10);
plot(tt,us_endosimul_100SD1Q_30,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_30,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_30,'LineWidth',2);
hold off
title('Employment Rate')
grid on

subplot(3,4,11);
plot(tt,us_endosimul_100SD1Q_4,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_4,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_4,'LineWidth',2);
hold off
title('Labor Force Participation Rate')
grid on

subplot(3,4,12);
plot(tt,us_endosimul_100SD1Q_5,'LineWidth',2);
hold on
plot(tt,us_endosimul_100SD2Q_5,'LineWidth',2);
plot(tt,us_endosimul_100SD3Q_5,'LineWidth',2);
hold off
title('Disutility of Labor Weight in Felicity Function')
grid on

saveas(gcf,'USGSW_amECsq_lockdown_simul3scenarios.fig')  % editable MATLAB format
saveas(gcf,'USGSW_amECsq_lockdown_simul3scenarios.eps')
saveas(gcf,'USGSW_amECsq_lockdown_simul3scenarios.epsc')
saveas(gcf,'USGSW_amECsq_lockdown_simul3scenarios.jpg')
saveas(gcf,'USGSW_amECsq_lockdown_simul3scenarios.png')
saveas(gcf,'USGSW_amECsq_lockdown_simul3scenarios.bmp')