%% MATLAB program: combplot_endosimul_lockdown_baseline5countries.m (created and run in R2017a on MacBook Pro OS)
%
%  Purpose:        This code generates and saves Figure 2 in DP combining 5 country baseline curves into 12 panels/subplots.
%
%  Excel Input:    USGSW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
%                  DEMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
%                  FRMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
%                  ITMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
%                  ESMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q               
%
%  First created:  5 April 2020, by Alexander Mihailov
%  Last modified:  10 May 2020, by Alexander Mihailov

%% Housekeeping and opening diary
close all                          % close all open figures
clear all                          % clear all earlier output
clc                                % clear command window
diary us_endosimul.txt             % create a diary log (*.txt) file saving the output from the command window
tic                                % start stopwatch timer
t = datetime('now')                % return a datetime scalar representing the current date and time

%% Define the vectors of simulated endogenous variables, reading into the respective Excel columns (as below)

% ADJUST FILENAME AND RANGE respectively below!!!

us_endosimul_100SD2Q = xlsread('USGSW_amECsq_lockdown_100SD2Qsimul.xlsx','Sheet1','A1:BJ44') % LF 100SD up for 2Q
de_endosimul_100SD2Q = xlsread('DEMRW_amECsq_lockdown_100SD2Qsimul.xlsx','Sheet1','A1:BJ44') % LF 100SD up for 2Q
fr_endosimul_100SD2Q = xlsread('FRMRW_amECsq_lockdown_100SD2Qsimul.xlsx','Sheet1','A1:BJ44') % LF 100SD up for 2Q
it_endosimul_100SD2Q = xlsread('ITMRW_amECsq_lockdown_100SD2Qsimul.xlsx','Sheet1','A1:BJ44') % LF 100SD up for 2Q
es_endosimul_100SD2Q = xlsread('ESMRW_amECsq_lockdown_100SD2Qsimul.xlsx','Sheet1','A1:BJ44') % LF 100SD up for 2Q

% Wage rate (row 32 in xlsx and var 32 in Dynare; w in code)

us_endosimul_100SD2Q_32 = us_endosimul_100SD2Q(32,:); % 100SD2Q LS shock down permanent
de_endosimul_100SD2Q_32 = de_endosimul_100SD2Q(32,:); % 100SD2Q LS shock down permanent
fr_endosimul_100SD2Q_32 = fr_endosimul_100SD2Q(32,:); % 100SD2Q LS shock down permanent
it_endosimul_100SD2Q_32 = it_endosimul_100SD2Q(32,:); % 100SD2Q LS shock down permanent
es_endosimul_100SD2Q_32 = es_endosimul_100SD2Q(32,:); % 100SD2Q LS shock down permanent

% Nominal policy rate (row 33 in xlsx and var 33 in Dynare; r in code)

us_endosimul_100SD2Q_33 = us_endosimul_100SD2Q(33,:);
de_endosimul_100SD2Q_33 = de_endosimul_100SD2Q(33,:);
fr_endosimul_100SD2Q_33 = fr_endosimul_100SD2Q(33,:);
it_endosimul_100SD2Q_33 = it_endosimul_100SD2Q(33,:);
es_endosimul_100SD2Q_33 = es_endosimul_100SD2Q(33,:);

% Consumption (row 27 in xlsx and var 27 in Dynare; c in code)

us_endosimul_100SD2Q_27 = us_endosimul_100SD2Q(27,:);
de_endosimul_100SD2Q_27 = de_endosimul_100SD2Q(27,:);
fr_endosimul_100SD2Q_27 = fr_endosimul_100SD2Q(27,:);
it_endosimul_100SD2Q_27 = it_endosimul_100SD2Q(27,:);
es_endosimul_100SD2Q_27 = es_endosimul_100SD2Q(27,:);

% Investment (row 28 in xlsx and var 28 in Dynare; inve in code)

us_endosimul_100SD2Q_28 = us_endosimul_100SD2Q(28,:);
de_endosimul_100SD2Q_28 = de_endosimul_100SD2Q(28,:);
fr_endosimul_100SD2Q_28 = fr_endosimul_100SD2Q(28,:);
it_endosimul_100SD2Q_28 = it_endosimul_100SD2Q(28,:);
es_endosimul_100SD2Q_28 = es_endosimul_100SD2Q(28,:);

% Output (row 29 in xlsx and var 29 in Dynare; y in code)

us_endosimul_100SD2Q_29 = us_endosimul_100SD2Q(29,:);
de_endosimul_100SD2Q_29 = de_endosimul_100SD2Q(29,:);
fr_endosimul_100SD2Q_29 = fr_endosimul_100SD2Q(29,:);
it_endosimul_100SD2Q_29 = it_endosimul_100SD2Q(29,:);
es_endosimul_100SD2Q_29 = es_endosimul_100SD2Q(29,:);

% Natural (flexible-price) output (row 18 in xlsx and var 18 in Dynare; yf in code)

us_endosimul_100SD2Q_18 = us_endosimul_100SD2Q(18,:);
de_endosimul_100SD2Q_18 = de_endosimul_100SD2Q(18,:);
fr_endosimul_100SD2Q_18 = fr_endosimul_100SD2Q(18,:);
it_endosimul_100SD2Q_18 = it_endosimul_100SD2Q(18,:);
es_endosimul_100SD2Q_18 = es_endosimul_100SD2Q(18,:);

% Output gap (row 44 in xlsx and var 44 in Dynare; ygap in code)

us_endosimul_100SD2Q_44 = us_endosimul_100SD2Q(44,:);
de_endosimul_100SD2Q_44 = de_endosimul_100SD2Q(44,:);
fr_endosimul_100SD2Q_44 = fr_endosimul_100SD2Q(44,:);
it_endosimul_100SD2Q_44 = it_endosimul_100SD2Q(44,:);
es_endosimul_100SD2Q_44 = es_endosimul_100SD2Q(44,:);

% Inflation rate (row 31 in xlsx and var 31 in Dynare; pinf in code)

us_endosimul_100SD2Q_31 = us_endosimul_100SD2Q(31,:);
de_endosimul_100SD2Q_31 = de_endosimul_100SD2Q(31,:);
fr_endosimul_100SD2Q_31 = fr_endosimul_100SD2Q(31,:);
it_endosimul_100SD2Q_31 = it_endosimul_100SD2Q(31,:);
es_endosimul_100SD2Q_31 = es_endosimul_100SD2Q(31,:);

% Unemployment rate (row 3 in xlsx and var 3 in Dynare; u in code)

us_endosimul_100SD2Q_3 = us_endosimul_100SD2Q(3,:);
de_endosimul_100SD2Q_3 = de_endosimul_100SD2Q(3,:);
fr_endosimul_100SD2Q_3 = fr_endosimul_100SD2Q(3,:);
it_endosimul_100SD2Q_3 = it_endosimul_100SD2Q(3,:);
es_endosimul_100SD2Q_3 = es_endosimul_100SD2Q(3,:);

% Employment rate (row 30 in xlsx and var 30 in Dynare; lab in code)

us_endosimul_100SD2Q_30 = us_endosimul_100SD2Q(30,:);
de_endosimul_100SD2Q_30 = de_endosimul_100SD2Q(30,:);
fr_endosimul_100SD2Q_30 = fr_endosimul_100SD2Q(30,:);
it_endosimul_100SD2Q_30 = it_endosimul_100SD2Q(30,:);
es_endosimul_100SD2Q_30 = es_endosimul_100SD2Q(30,:);

% Labour force participation rate (row 4 in xlsx and var 4 in Dynare; labstar in code) 

us_endosimul_100SD2Q_4 = us_endosimul_100SD2Q(4,:);
de_endosimul_100SD2Q_4 = de_endosimul_100SD2Q(4,:);
fr_endosimul_100SD2Q_4 = fr_endosimul_100SD2Q(4,:);
it_endosimul_100SD2Q_4 = it_endosimul_100SD2Q(4,:);
es_endosimul_100SD2Q_4 = es_endosimul_100SD2Q(4,:);

% Disutility of labor weight in U f-n = adverse LS shock in GSW (row 5 in xlsx and var 5 in Dynare; labstar in code)

us_endosimul_100SD2Q_5 = us_endosimul_100SD2Q(5,:);
%de_endosimul_100SD2Q_5 = de_endosimul_100SD2Q(5,:);
%fr_endosimul_100SD2Q_5 = fr_endosimul_100SD2Q(5,:);
%it_endosimul_100SD2Q_5 = it_endosimul_100SD2Q(5,:);
%es_endosimul_100SD2Q_5 = es_endosimul_100SD2Q(5,:);

%Figure (without caption title)
figure

% x-axis: 62 quarters - quarter 1 initial, quarter 62 terminal, in-between 60 quarters entered in Dynare simul command
tt=1:62;  % AM200320: Dynare adds to the 60 quarters entered in "simul" above both the initial and the terminal values!
          % The command "tt" defines the horizontal axis length in "plot" next, corresponding to the specified periods!

subplot(3,4,1);
plot(tt,us_endosimul_100SD2Q_32,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_32,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_32,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_32,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_32,'LineWidth',2);
hold off
hleg1 = legend({'US','DE','FR','IT','ES'},'FontSize',10);
set(hleg1,'Location','NorthEast')
title('Wage Rate')
grid on

subplot(3,4,2);
plot(tt,us_endosimul_100SD2Q_33,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_33,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_33,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_33,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_33,'LineWidth',2);
hold off
title('Nominal Policy Rate')
grid on

subplot(3,4,3);
plot(tt,us_endosimul_100SD2Q_27,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_27,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_27,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_27,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_27,'LineWidth',2);
hold off
title('Consumption')
grid on

subplot(3,4,4);
plot(tt,us_endosimul_100SD2Q_28,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_28,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_28,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_28,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_28,'LineWidth',2);
hold off
title('Investment')
grid on

subplot(3,4,5);
plot(tt,us_endosimul_100SD2Q_29,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_29,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_29,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_29,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_29,'LineWidth',2);
hold off
title('Output')
grid on

subplot(3,4,6);
plot(tt,us_endosimul_100SD2Q_18,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_18,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_18,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_18,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_18,'LineWidth',2);
hold off
title('Natural (Flex-Price) Output')
grid on

subplot(3,4,7);
plot(tt,us_endosimul_100SD2Q_44,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_44,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_44,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_44,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_44,'LineWidth',2);
hold off       
title('Output Gap')
grid on

subplot(3,4,8);
plot(tt,us_endosimul_100SD2Q_31,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_31,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_31,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_31,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_31,'LineWidth',2);
hold off
title('Inflation Rate')
grid on

subplot(3,4,9);
plot(tt,us_endosimul_100SD2Q_3,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_3,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_3,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_3,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_3,'LineWidth',2);
hold off
title('Unemployment Rate');
grid on

subplot(3,4,10);
plot(tt,us_endosimul_100SD2Q_30,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_30,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_30,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_30,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_30,'LineWidth',2);
hold off
title('Employment Rate')
grid on

subplot(3,4,11);
plot(tt,us_endosimul_100SD2Q_4,'LineWidth',2);
hold on
plot(tt,de_endosimul_100SD2Q_4,'LineWidth',2);
plot(tt,fr_endosimul_100SD2Q_4,'LineWidth',2);
plot(tt,it_endosimul_100SD2Q_4,'LineWidth',2);
plot(tt,es_endosimul_100SD2Q_4,'LineWidth',2);
hold off
title('Labor Force Participation Rate')
grid on

subplot(3,4,12);
plot(tt,us_endosimul_100SD2Q_5,'LineWidth',2);
hold on
%plot(tt,de_endosimul_100SD2Q_5,'LineWidth',2);
%plot(tt,fr_endosimul_100SD2Q_5,'LineWidth',2);
%plot(tt,it_endosimul_100SD2Q_5,'LineWidth',2);
%plot(tt,es_endosimul_100SD2Q_5,'LineWidth',2);
hold off
title('Disutility of Labor Weight in Felicity Function')
grid on

saveas(gcf,'all5_amECsq_lockdown_simulbaseline.fig')  % editable MATLAB format
saveas(gcf,'all5_amECsq_lockdown_simulbaseline.eps')
saveas(gcf,'all5_amECsq_lockdown_simulbaseline.epsc')
saveas(gcf,'all5_amECsq_lockdown_simulbaseline.jpg')
saveas(gcf,'all5_amECsq_lockdown_simulbaseline.png')
saveas(gcf,'all5_amECsq_lockdown_simulbaseline.bmp')