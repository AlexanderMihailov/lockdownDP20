readme_lockdown_200510.txt
AM200510
___________________________________________________________

This readme_lockdown_200510.txt file describes the structure of the lockdown_200510.zip archive and the steps in the replication of the simulations in “Quantifying the Macroeconomic Effects of the COVID-19 Lockdown: Comparative Simulations of the Estimated Galí-Smets-Wouters Model” by Alexander Mihailov, Economics Department Discussion Paper 2020-07 (10 April 2020), University of Reading, UK:
http://www.reading.ac.uk/web/files/economics/emdp202007.pdf

The most extensive simulations are performed for the United States (US), which is the benchmark country. There are also partial analogous simulations for France (FR), Germany (DE), Italy (IT) and Spain (ES).

The main Dynare code used (by country), is a minor modification of the original Dynare code, us_mar2011s_N_172.mod, kindly provided by Raf Wouters in a nbb.zip archive via e-mail to me on 180716. The code and US data were used in GSW (2012) = Gali, Smets and Wouters (2012: NBER Macro Annual), "Unemployment in an Estimated New Keynesian Model"; the original formatting is kept on purpose, as it parallels that of the similar Dynare code of SW (2007) = Smets and Wouters (2007: AER), "Shocks and Frictions in US Business Cycles: A Bayesian DSGE Approach."

A version of the code was used for estimation based on data of 4 EMU countries (FR, DE, IT and ES) reported in "Heterogeneous Effects of Single Monetary Policy on Unemployment Rates in the Largest EMU Countries", by Alexander Mihailov, Giovanni Razzu and Zhe Wang, Economics Department Discussion Paper 2019-07 (April 2019), University of Reading, UK:
http://www.reading.ac.uk/web/files/economics/emdp201907.pdf

The programs have been run in Dynare 4.5.1 and MATLAB R2017a on a MacBook Pro OS laptop (5-10 May 2020).
___________________________________________________________

Our simulation design consists of two steps/stages/types of shocks, and then generating the comparative figures.
___________________________________________________________

I. Assuming and coding a temporary labor supply shock
___________________________________________________________

Dynare codes:

USGSW_amECsq_lockdown.mod - for the US (calibrated according to the estimates in GSW 2012, see Table 3 in DP)
FRMRW_amECsq_lockdown.mod - for France (calibrated according to the estimates in MRW 2019, see Table 3 in DP)
DEMRW_amECsq_lockdown.mod - for Germany (calibrated according to the estimates in MRW 2019, see Table 3 in DP)
ITMRW_amECsq_lockdown.mod - for Italy (calibrated according to the estimates in MRW 2019, see Table 3 in DP)
ESMRW_amECsq_lockdown.mod - for Spain (calibrated according to the estimates in MRW 2019, see Tabler 3 in DP)

When the shock is temporary, implying a return to the initial steady state (SS) of the disutility from work, the shock equals:

(a) either 100 standard deviations (SD), implying 1.2 times higher disutility from work (e.g., due to risk of contagion and death in the current COVID-19 lockdown context) and chosen to match a resulting 1/4 drop in the labor force (i.e., our most optimistic version of the ability to work from home or on the workplace for the remaining 3/4 of the labor force, given the varied practices across countries in the world nowadays) and providing what we refer to as the "lower bound of the temporary macroeconomic loss" from it;

(b) or 300 SD (3.5 times higher disutility to work chosen to match a resulting 3/4 drop in the labor force), providing the "upper bound of the temporary macroeconomic loss";

The SD is measured by the estimated posterior mean of the SD of the innovation in the labor supply shock in the US sample of GSW (ls = 1:17%, see Table 3). 

For each of these "bounds of the temporary macroeconomic loss", lower and upper, we then simulate 3 scenarios, labeled as:

(i) "optimistic", defined by 1 quarter assumed duration of the lockdown;
(ii) "baseline", 2 quarters of duration;
(iii) "pessimistic", 3 quarters of duration.

The (a) and (b) / (i), (ii) and (iii) versions of the code are run after changing the respective magnitude in each code run. The simulation results of each such code run that are saved, by default, in a MATLAB output matrix (*.mat) file) are also copy/pasted, for ease of reference and use, in respective Excel tables, and then used as input in the MATLAB file producing the reported figures. These Excel tables, included in the zip archive, are easily identifiable by their file names (see also the section on generating the figures 1-3 below).
___________________________________________________________

II. Assuming and coding a permanent shock
___________________________________________________________

Dynare code (run for the US only, so far): 

USGSW_amECsq_lockdown_death.mod - for the US (calibrated according to the estimates in GSW 2012, see Table 3 in DP)

When the shock is permanent, we calibrate this the simulation set in 3 scenarios, again:

(i) "optimistic", where the size of the permanent labor supply shock is 1 US SD, the new SS of the disutility from work is a little bit above 1 p.p. from the initial SS, and that of the LFPR is a bit less than 0.3 p.p. below the initial SS;

(ii) "baseline", where the corresponding assumptions are 3 US SD, about 3.5 p.p. above SS for the disutility from work, and about 0.6 p.p. below SS for the LFPR;

(iii) "pessimistic", where the analogous assumptions are still less favorable, respectively: 5 US SD, nearly 6 p.p. higher disutility from labor, and about 1 p.p. lower LFPR in the terminal SS.

Again, (i), (ii) and (iii) versions of the code are run after changing the respective magnitude in each code run. The simulation results of each such code run that are saved, by default, in a MATLAB output matrix (*.mat) file) are also copy/pasted, for ease of reference and use, in respective Excel tables, and then used as input in the MATLAB file producing the reported figures. These Excel tables, included in the zip archive, are easily identifiable by their file names (see also the section on generating the Figure 4 below).
___________________________________________________________

III. Generating the figures (in DP)
___________________________________________________________

Figure 1 (in DP)
___________________________________________________________

MATLAB program: combplot_endosimul_lockdown.m (created and run in R2017a on MacBook Pro OS)

Purpose:        This code generates and saves Figure 1 in DP combining 3 US scenario curves into 12 panels/subplots.

Excel Input:    USGSW_amECsq_lockdown_100SD1Qsimul.xlsx - simulation assuming LF 100SD up for 1Q
                USGSW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
                USGSW_amECsq_lockdown_100SD3Qsimul.xlsx - simulation assuming LF 100SD up for 3Q
___________________________________________________________

Figure 2 (in DP)
___________________________________________________________

MATLAB program: combplot_endosimul_lockdown_baseline5countries.m (created and run in R2017a on MacBook Pro OS)

Purpose:        This code generates and saves Figure 2 in DP combining 5 country baseline curves into 12 panels/subplots.

Excel Input:    USGSW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
                DEMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
                FRMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
                ITMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
                ESMRW_amECsq_lockdown_100SD2Qsimul.xlsx - simulation assuming LF 100SD up for 2Q
___________________________________________________________

Figure 3 (in DP)
___________________________________________________________

MATLAB program: combplot_endosimul_lockdown_worse.m (created and run in R2017a on MacBook Pro OS)

Purpose:        This code generates and saves Figure 3 in DP combining 3 US scenario curves into 12 panels/subplots.

Excel Input:    USGSW_amECsq_lockdown_300SD1Qsimul.xlsx - simulation assuming LF 300SD up for 1Q
                USGSW_amECsq_lockdown_300SD2Qsimul.xlsx - simulation assuming LF 300SD up for 2Q
                USGSW_amECsq_lockdown_300SD3Qsimul.xlsx - simulation assuming LF 300SD up for 3Q
___________________________________________________________

Figure 4 (in DP)
___________________________________________________________

MATLAB program: combplot_endosimul_death.m (created and run in R2017a on MacBook Pro OS)

Purpose:        This code generates and saves Figure 4 in DP combining 3 US scenario curves into 12 panels/subplots.

Excel Input:    USGSW_amECsq_lockdown_death_1SDsimul.xlsx - simulation assuming LF 1SD down in new SS = 1% of LF dead
                USGSW_amECsq_lockdown_death_3SDsimul.xlsx - simulation assuming LF 3SD down in new SS = 1% of LF dead
                USGSW_amECsq_lockdown_death_5SDsimul.xlsx - simulation assuming LF 5SD down in new SS = 1% of LF dead
___________________________________________________________

Alexander Mihailov
Department of Economics
University of Reading
United Kingdom

a.mihailov@reading.ac.uk
a_mihailov@hotmail.com

Reading, 10 May 2020

